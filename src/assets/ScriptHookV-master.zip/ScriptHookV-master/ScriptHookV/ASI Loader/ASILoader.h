#ifndef __ASI_LOADER_H__
#define __ASI_LOADER_H__

#include "..\ScriptHookV.h"

namespace ASILoader 
{
	void Initialize();
};

#endif // __ASI_LOADER_H__